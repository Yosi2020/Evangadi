<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require './srs/PHPMailer/Exception.php';
require './srs/PHPMailer/PHPMailer.php';
require './srs/PHPMailer/SMTP.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = sanitize_input($_POST["name"]);
    $email = sanitize_input($_POST["email"]);
    $subject = sanitize_input($_POST["subject"]);
    $message = sanitize_input($_POST["message"]);

    $to = "eyosiyas.tibebuendalamaw@gmail.com";

    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = 'eyosiyastibebu.com'; // Replace 'yourdomain.com' with your actual domain
        $mail->SMTPAuth = true;
        $mail->Username = 'info@eyosiyastibebu.com'; // Your email address on Yegara hosting
        $mail->Password = '%8NpH6m%'; // Your email password
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        // Recipients
        $mail->setFrom($email, $name);
        $mail->addAddress($to);

        // Content
        $mail->isHTML(false);
        $mail->Subject = $subject;
        $mail->Body = "Name: " . $name . "\n";
        $mail->Body .= "Email: " . $email . "\n";
        $mail->Body .= "Subject: " . $subject . "\n";
        $mail->Body .= "Message: \n" . $message . "\n";

        $mail->send();
        // echo "Your message has been sent. Thank you!";
    } catch (Exception $e) {
        echo "There was an error sending your message. Please try again.";
    }
}

function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
